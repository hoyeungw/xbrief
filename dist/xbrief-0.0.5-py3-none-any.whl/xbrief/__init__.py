__author__ = 'Hoyeung Wong'
__name__ = 'xbrief'

from .deco import deco_entries, deco_matrix, deco_vector
